<?php
    require_once "koneksi.php";

    $result = ['status' => false, 'msg' => 'Access denied'];
    if(isset($_GET['cmd'])) {
        if($_GET['cmd'] == "OutboundListEFS") {
            $query = $koneksi->query("SELECT * FROM OutboundListEFS");
            $fetch = $query->fetch_assoc();

            $result['status'] = true;
            $result['msg'] = "Result OutboundListEFS";
            $result['datas'] = $fetch;
        }
    }

    echo json_encode($result);
    die;

?>